﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Activity_Three
{
    public static class PasswordHelper
    {
        public static string HashPassword(string password)
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] salt = new byte[16];
                rng.GetBytes(salt);
                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, 10000))
                {
                    byte[] hash = pbkdf2.GetBytes(32);
                    return $"PBKDF2$10000${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
                }
            }
        }
        public static bool VerifyPassword(string password, string storedHash)
        {
            try
            {
                string[] parts = storedHash.Split('$');

                if (parts.Length != 4 || parts[0] != "PBKDF2")
                    return false;
                int iterations = int.Parse(parts[1]);
                byte[] salt = Convert.FromBase64String(parts[2]);
                byte[] originalHash = Convert.FromBase64String(parts[3]);

                using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations))
                {
                    byte[] newhash = pbkdf2.GetBytes(32);

                    if (newhash.Length != originalHash.Length)
                        return false;

                    int difference = 0;

                    for (int i = 0; i < newhash.Length; i++)
                    {
                        difference |= newhash[i] ^ originalHash[i];
                    }
                    return difference == 0;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
