﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity_Three
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            loginbtn.Click += loginbtn_Click;
            txtpassword.UseSystemPasswordChar = true;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            string username = txtusername.Text.Trim();
            string password = txtpassword.Text;

            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                using (OleDbConnection con = Database.GetConnection())
                {
                    con.Open();
                    string query = "SELECT * FROM UserAccess WHERE Username = ?";

                    using (OleDbCommand cmd = new OleDbCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                                if (!reader.Read())
                                {
                                    MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                string storedHash = reader["Password"].ToString() ?? "";
                                string fullname = reader["Fullname"].ToString() ?? "";
                                string userrole = reader["UserRole"].ToString() ?? "";
                                bool isActive = Convert.ToBoolean(reader["IsActive"]);
                                int userId = Convert.ToInt32(reader["UserID"]);

                                if (!PasswordHelper.VerifyPassword(password, storedHash))
                                {
                                    MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;

                                }
                                if (!isActive)
                                {
                                    MessageBox.Show("Your Account is inactive. Please contact the administrator.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }
                                MessageBox.Show($"Welcome {fullname}!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                reader.Close();

                                Dashboard dashboard = new Dashboard();
                                dashboard.Show();
                                this.Hide();
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show($"An error occurred while logging in.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void signuplink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Signup signup = new Signup();
            signup.Show();
            this.Hide();
        }
    }
}
