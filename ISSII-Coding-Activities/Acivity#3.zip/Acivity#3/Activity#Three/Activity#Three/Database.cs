﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity_Three
{
    public static class Database
    {
        public static readonly String DBPath =
           Path.GetFullPath(
               Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\InventoryDB.accdb")
           );
        private static readonly String ConnectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={DBPath}; Persist Security Info=False;";

        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(ConnectionString);
        }
    }
}
